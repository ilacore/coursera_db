# Data-Manipulation-at-Scale-Systems-and-Algorithms-
Coursera Course
https://www.coursera.org/learn/data-manipulation/
